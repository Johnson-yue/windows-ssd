function version_str = version()
% version()
%   show Caffe's version.

version_str = caffe_('version');

end
